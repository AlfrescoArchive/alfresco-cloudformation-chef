default['commons']['install_awscli'] = true
default['commons']['awscli']['aws_region'] = "us-east-1"
default['commons']['awscli']['credentials_parent_path'] = "/root/.aws"
default['commons']['awscli']['force_commandline_install'] = true
default['commons']['awscli']['aws_command'] = 'aws'

# default['commons']['awscli']['credentials_databag'] = "aws"
# default['commons']['awscli']['credentials_databag_item'] = "local"
