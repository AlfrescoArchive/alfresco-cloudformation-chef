# Example of tag creation for the current box
# default['commons']['ec2_tags']['roles'] = 'role1,role2'
# default['commons']['ec2_tags']['instance_name'] = 'my-instance-name1'
# default['commons']['ec2_tags']['jvm_route'] = 'n1'
