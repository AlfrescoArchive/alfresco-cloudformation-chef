Put your .lic file in this folder; it will be ignored by chef/berkshelf and git
