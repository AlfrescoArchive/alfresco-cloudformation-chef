# TODO - work in progress here...

# ps aux | grep tomcat-alfresco | grep -v grep | awk '{print $2}'

# jmxterm_jar_source = "http://sourceforge.net/projects/cyclops-group/files/jmxterm/1.0-alpha-4/jmxterm-1.0-alpha-4-uber.jar/download"
#
# remote_file "/opt/jmxterm.jar" do
#   source jmxterm_jar_source
# end
#
# execute 'run-jmxterm' do
#   command "java -jar /opt/jmxterm.jar << "
# end
