node.default['artifacts']['googledocs-repo']['enabled'] = true
node.default['artifacts']['googledocs-share']['enabled'] = true
