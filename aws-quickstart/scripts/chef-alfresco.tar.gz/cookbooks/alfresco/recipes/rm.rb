node.default['artifacts']['rm']['enabled'] = true
node.default['artifacts']['rm-share']['enabled'] = true
