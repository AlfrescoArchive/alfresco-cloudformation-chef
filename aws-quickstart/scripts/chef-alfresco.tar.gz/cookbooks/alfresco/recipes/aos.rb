node.default['artifacts']['_vti_bin']['enabled'] = true
node.default['artifacts']['ROOT']['enabled'] = true
