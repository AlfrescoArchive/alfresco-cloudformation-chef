alfresco_haproxy_config 'haproxy-config' do
  action :run
end
