default['alfresco']['certs']['filename'] = 'alfresco'
default['alfresco']['certs']['ssl_fqdn'] = node['alfresco']['public_hostname']
default['alfresco']['certs']['ssl_folder'] = "/etc/pki/tls/certs"
